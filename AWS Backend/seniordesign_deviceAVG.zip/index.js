const mysql = require('mysql');
const con = mysql.createConnection({
  host     : process.env.RDS_HOSTNAME,
  user     : process.env.RDS_USERNAME,
  password : process.env.RDS_PASSWORD,
  port     : process.env.RDS_PORT,
  database : process.env.RDS_DATABASE
});
exports.handler = (event, context, callback) => {
  // allows for using callbacks as finish/error-handlers
  context.callbackWaitsForEmptyEventLoop = false;
  // const eventObj = JSON.parse(event.body).Device;
  // const deviceId = event.Device;
  // const query = deviceId.toString();
  // console.log(event.Device);
  let query = event.pathParameters.device;
  const sql = "select * from deviceavg where device_deviceid = " + query;
  console.log(event);
  con.query(sql, function (err, result) {
    if (err) throw err;
    callback(null, {
      statusCode: err ? '400' : '200',
      body: err ? err : JSON.stringify(result),
      isBase64Encoded: false,
      headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
      }})
  });
};