
var mysql = require('mysql');
// Use pool for connection pooling to allow for multiple queries
var pool = mysql.createPool({
  host     : process.env.RDS_HOSTNAME,
  user     : process.env.RDS_USERNAME,
  password : process.env.RDS_PASSWORD,
  port     : process.env.RDS_PORT,
  database : process.env.RDS_DATABASE
});

// Invoke our handler
exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false; // Set to false to send the response right away when the callback runs

  // Get the connection we made to our RDS
  pool.getConnection(function(err, connection) {

      // Drop our average tables so we can repopulate them
      connection.query('drop table deviceavg;', function (error, results, fields) {
          if (error) callback(error) ;
      });
      connection.query('drop table weatheravg;', function (error, results, fields) {
          if (error) callback(error) ;
      });
      
      // Recreate our average tables
      connection.query('CREATE TABLE IF NOT EXISTS `seniordesign`.`deviceavg` ( \
                          `avgid` INT NOT NULL AUTO_INCREMENT, \
                          `device_deviceid` INT NOT NULL, \
                          `time` INT NULL, \
                          `average` FLOAT NULL, \
                          INDEX `fk_deviceavg_device1_idx` (`device_deviceid` ASC) VISIBLE, \
                          PRIMARY KEY (`avgid`), \
                          UNIQUE INDEX `avgid_UNIQUE` (`avgid` ASC) VISIBLE, \
                          CONSTRAINT `fk_deviceavg_device1` \
                          FOREIGN KEY (`device_deviceid`) \
                          REFERENCES `seniordesign`.`device` (`deviceid`) \
                          ON DELETE NO ACTION \
                          ON UPDATE NO ACTION) \
                          ENGINE = InnoDB;', function (error, results, fields) {
          if (error) callback(error) ;
      });
      connection.query('CREATE TABLE IF NOT EXISTS `seniordesign`.`weatheravg` ( \
                          `avgid` INT NOT NULL AUTO_INCREMENT, \
                          `citydata_cityid` INT NOT NULL, \
                          `time` INT NULL, \
                          `tempavg` FLOAT NULL, \
                          `humidityavg` FLOAT NULL, \
                          `pressureavg` FLOAT NULL, \
                          `windspeedavg` FLOAT NULL, \
                          `dewpointavg` FLOAT NULL, \
                          PRIMARY KEY (`avgid`), \
                          UNIQUE INDEX `avgid_UNIQUE` (`avgid` ASC) VISIBLE, \
                          INDEX `fk_deviceavg_copy1_citydata1_idx` (`citydata_cityid` ASC) VISIBLE, \
                          CONSTRAINT `fk_deviceavg_copy1_citydata1` \
                          FOREIGN KEY (`citydata_cityid`) \
                          REFERENCES `seniordesign`.`citydata` (`cityid`) \
                          ON DELETE NO ACTION \
                          ON UPDATE NO ACTION) \
                          ENGINE = InnoDB;', function (error, results, fields) {
          if (error) callback(error) ;
      });

      // Insert monthly averages from house overall
      connection.query('insert into deviceavg (device_deviceid, time, average) select device_deviceid, \
                          (floor(time/(60))*60) AS hour, avg(energyuse) FROM devicedata where device_deviceid = 1 \
                          and time >= ((select time from devicedata where device_deviceid = 1 ORDER BY devicedataid DESC LIMIT 1) - 43740) \
                          GROUP BY floor(time/(60));', function (error, results, fields) {
          if (error) callback(error) ;
      });
      
      // Insert monthly averages from dishwasher
      connection.query('insert into deviceavg (device_deviceid, time, average) select device_deviceid, \
                          (floor(time/(60))*60) AS hour, avg(energyuse) FROM devicedata where device_deviceid = 2 \
                          and time >= ((select time from devicedata where device_deviceid = 2 ORDER BY devicedataid DESC LIMIT 1) - 43740) \
                          GROUP BY floor(time/(60));', function (error, results, fields) {
          if (error) callback(error) ;
      });

      // Insert monthly averages from home office
      connection.query('insert into deviceavg (device_deviceid, time, average) select device_deviceid, \
                          (floor(time/(60))*60) AS hour, avg(energyuse) FROM devicedata where device_deviceid = 3 \
                          and time >= ((select time from devicedata where device_deviceid = 3 ORDER BY devicedataid DESC LIMIT 1) - 43740) \
                          GROUP BY floor(time/(60));', function (error, results, fields) {
          if (error) callback(error) ;
      });

      // Insert monthly averages from fridge
      connection.query('insert into deviceavg (device_deviceid, time, average) select device_deviceid, \
                          (floor(time/(60))*60) AS hour, avg(energyuse) FROM devicedata where device_deviceid = 4 \
                          and time >= ((select time from devicedata where device_deviceid = 4 ORDER BY devicedataid DESC LIMIT 1) - 43740) \
                          GROUP BY floor(time/(60));', function (error, results, fields) {
          if (error) callback(error) ;
      });

      // Insert monthly averages from kitchen total
      connection.query('insert into deviceavg (device_deviceid, time, average) select device_deviceid, \
                          (floor(time/(60))*60) AS hour, avg(energyuse) FROM devicedata where device_deviceid = 5 \
                          and time >= ((select time from devicedata where device_deviceid = 5 ORDER BY devicedataid DESC LIMIT 1) - 43740) \
                          GROUP BY floor(time/(60));', function (error, results, fields) {
          if (error) callback(error) ;
      });

      // Insert monthly averages from microwave
      connection.query('insert into deviceavg (device_deviceid, time, average) select device_deviceid, \
                          (floor(time/(60))*60) AS hour, avg(energyuse) FROM devicedata where device_deviceid = 6 \
                          and time >= ((select time from devicedata where device_deviceid = 6 ORDER BY devicedataid DESC LIMIT 1) - 43740) \
                          GROUP BY floor(time/(60));', function (error, results, fields) {
          if (error) callback(error) ;
      });

      // Insert monthly averages from living room
      connection.query('insert into deviceavg (device_deviceid, time, average) select device_deviceid, \
                          (floor(time/(60))*60) AS hour, avg(energyuse) FROM devicedata where device_deviceid = 7 \
                          and time >= ((select time from devicedata where device_deviceid = 7 ORDER BY devicedataid DESC LIMIT 1) - 43740) \
                          GROUP BY floor(time/(60));', function (error, results, fields) {
          if (error) callback(error) ;
      });

      // Insert all weather data averages
      connection.query('insert into weatheravg (citydata_cityid, time, tempavg, humidityavg, pressureavg, windspeedavg, dewpointavg) \
                          select citydata_cityid, (floor(time/(60))*60) AS hour, avg(temp), avg(humidity), avg(pressure), avg(windspeed), \
                          avg(dewpoint) FROM weatherdata where citydata_cityid = 1 and \
                          time >= ((select time from weatherdata where citydata_cityid = 1 ORDER BY weatherid DESC LIMIT 1) - 43740) \
                          GROUP BY floor(time/(60));', function (error, results, fields) {
          // Were done with the connection so release it
          connection.release();
          if (error) callback(error);
          else callback(null, "Inserted data for 7 devices and 1 weather table successfully");
      });
  });
};