import time
import json
import boto3

def lambda_handler(event, context):

    # boto3 client
    client = boto3.client('ec2')
    ssm = boto3.client('ssm')
        
    instanceid = 'i-0cc3035c7cc811fc7'
    response = ""
    print(instanceid)
    
    ######################################################### Device 1 ######################################################################
    response = ssm.send_command(
            InstanceIds=[instanceid],
            DocumentName="AWS-RunShellScript",
            TimeoutSeconds=123,
            Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py -d 1']} # replace command_to_be_executed with command
            )
    # Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py']} # replace command_to_be_executed with command
    command_id = response['Command']['CommandId']
    
    # we must wait for command to finish before we query the get_command_invocation on the instance, or else the Plugins list will be empty and we will crash
    keepWaiting = None
    while keepWaiting is None: 
        response = ssm.list_commands(
            CommandId=command_id
        )
        if response['Commands'][0]['Status'] == "InProgress" or response['Commands'][0]['Status'] == "Pending":            
            time.sleep(30)
        else:
            keepWaiting = 1

    ######################################################### Device 2 ######################################################################
    response = ssm.send_command(
            InstanceIds=[instanceid],
            DocumentName="AWS-RunShellScript",
            TimeoutSeconds=123,
            Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py -d 2']} # replace command_to_be_executed with command
            )
    # Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py']} # replace command_to_be_executed with command
    command_id = response['Command']['CommandId']
    
    # we must wait for command to finish before we query the get_command_invocation on the instance, or else the Plugins list will be empty and we will crash
    keepWaiting = None
    while keepWaiting is None: 
        response = ssm.list_commands(
            CommandId=command_id
        )
        if response['Commands'][0]['Status'] == "InProgress" or response['Commands'][0]['Status'] == "Pending":            
            time.sleep(30)
        else:
            keepWaiting = 1
    
    ######################################################### Device 3 ######################################################################
    response = ssm.send_command(
            InstanceIds=[instanceid],
            DocumentName="AWS-RunShellScript",
            TimeoutSeconds=123,
            Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py -d 3']} # replace command_to_be_executed with command
            )
    # Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py']} # replace command_to_be_executed with command
    command_id = response['Command']['CommandId']
    
    # we must wait for command to finish before we query the get_command_invocation on the instance, or else the Plugins list will be empty and we will crash
    keepWaiting = None
    while keepWaiting is None: 
        response = ssm.list_commands(
            CommandId=command_id
        )
        if response['Commands'][0]['Status'] == "InProgress" or response['Commands'][0]['Status'] == "Pending":            
            time.sleep(30)
        else:
            keepWaiting = 1
    
    ######################################################### Device 4 ######################################################################
    response = ssm.send_command(
            InstanceIds=[instanceid],
            DocumentName="AWS-RunShellScript",
            TimeoutSeconds=123,
            Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py -d 4']} # replace command_to_be_executed with command
            )
    # Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py']} # replace command_to_be_executed with command
    command_id = response['Command']['CommandId']
    
    # we must wait for command to finish before we query the get_command_invocation on the instance, or else the Plugins list will be empty and we will crash
    keepWaiting = None
    while keepWaiting is None: 
        response = ssm.list_commands(
            CommandId=command_id
        )
        if response['Commands'][0]['Status'] == "InProgress" or response['Commands'][0]['Status'] == "Pending":            
            time.sleep(30)
        else:
            keepWaiting = 1
    
    ######################################################### Device 5 ######################################################################
    response = ssm.send_command(
            InstanceIds=[instanceid],
            DocumentName="AWS-RunShellScript",
            TimeoutSeconds=123,
            Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py -d 5']} # replace command_to_be_executed with command
            )
    # Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py']} # replace command_to_be_executed with command
    command_id = response['Command']['CommandId']
    
    # we must wait for command to finish before we query the get_command_invocation on the instance, or else the Plugins list will be empty and we will crash
    keepWaiting = None
    while keepWaiting is None: 
        response = ssm.list_commands(
            CommandId=command_id
        )
        if response['Commands'][0]['Status'] == "InProgress" or response['Commands'][0]['Status'] == "Pending":            
            time.sleep(30)
        else:
            keepWaiting = 1

    ######################################################### Device 6 ######################################################################
    response = ssm.send_command(
            InstanceIds=[instanceid],
            DocumentName="AWS-RunShellScript",
            TimeoutSeconds=123,
            Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py -d 6']} # replace command_to_be_executed with command
            )
    # Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py']} # replace command_to_be_executed with command
    command_id = response['Command']['CommandId']
    
    # we must wait for command to finish before we query the get_command_invocation on the instance, or else the Plugins list will be empty and we will crash
    keepWaiting = None
    while keepWaiting is None: 
        response = ssm.list_commands(
            CommandId=command_id
        )
        if response['Commands'][0]['Status'] == "InProgress" or response['Commands'][0]['Status'] == "Pending":            
            time.sleep(30)
        else:
            keepWaiting = 1

    ######################################################### Device 7 ######################################################################
    response = ssm.send_command(
            InstanceIds=[instanceid],
            DocumentName="AWS-RunShellScript",
            TimeoutSeconds=123,
            Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py -d 7']} # replace command_to_be_executed with command
            )
    # Parameters={'commands': ['cd /home/ec2-user','python3 ML_single_device.py']} # replace command_to_be_executed with command
    command_id = response['Command']['CommandId']
    
    # we must wait for command to finish before we query the get_command_invocation on the instance, or else the Plugins list will be empty and we will crash
    keepWaiting = None
    while keepWaiting is None: 
        response = ssm.list_commands(
            CommandId=command_id
        )
        if response['Commands'][0]['Status'] == "InProgress" or response['Commands'][0]['Status'] == "Pending":            
            time.sleep(30)
        else:
            keepWaiting = 1

    # fetching command output
    output = ssm.get_command_invocation(
          CommandId=command_id,
          InstanceId=instanceid
        )
    print(output)

    return {
        'statusCode': 200,
        'body': json.dumps('Thanks from Srce Cde!')
    }